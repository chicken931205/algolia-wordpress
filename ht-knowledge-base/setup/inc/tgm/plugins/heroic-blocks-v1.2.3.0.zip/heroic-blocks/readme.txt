=== Heroic Blocks ===
Contributors: herothemes
Tags: blocks
Requires at least: 5.8
Tested up to: 5.9
Version: 1.2.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Heroic Blocks allows you to add various blocks to WordPress content

== Description ==

Add various elements to your work

== Installation ==

It's easy to get started

1. Upload `ht-blocks` unzipped folder to the `/wp-content/plugins/` directory or goto Plugins > Add New and upload the Heroic Blocks zipped file.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Click on the drop down in the visual editor to add any of the blocks. The blocks are contained in the Heroic Blocks section.


== Frequently Asked Questions ==

= Q. I have a question! =

A. Please goto herothemes.com/support for assistance


== Screenshots ==



== Changelog ==

= 1.2.3 =
(16 Feb 2022)

Improved! Compatibility checks and improvements for WP5.9
Improved! Block consistency and performance
Fixed! Issue with webpack loading in production environments

= 1.2.2 =
(27 Oct 2021)

Fixed! WP5.8 compatibility fix

= 1.2.1 =
(15 Mar 2021)

Fixed! WP5.7 block preview hotfix

= 1.2.0 =
(3 Sep 2020)

New! Added image block

= 1.1.0 =
(16 Apr 2020)

New! Added list block

= 1.0.0 =
(12 Apr 2019)

New! Initial release.


== Developer Notes ==

