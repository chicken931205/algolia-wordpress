<!-- wp:paragraph -->
<p>Egone non intellego, quid sit don Graece, Latine voluptas? Tum, Quintus et Pomponius cum idem se velle dixissent, Piso exorsus est. Duo Reges: constructio interrete. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Orci nulla pellentesque dignissim enim sit amet venenatis. Vel eros donec ac odio. </p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>Eget Mauris Pharetra</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>In nulla posuere sollicitudin aliquam. Ut aliquam purus sit amet luctus venenatis lectus. Morbi quis commodo odio aenean sed. Odio tempor orci dapibus ultrices in. Arcu dui vivamus arcu felis. At imperdiet dui accumsan sit amet nulla facilisi morbi. </p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul><li>Congue mauris rhoncus aenean vel elit. </li><li>Amet nisl suscipit adipiscing bibendum est ultricies. </li><li>Pharetra sit amet aliquam id diam maecenas. </li><li>Adipiscing vitae proin sagittis nisl. </li></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Neque volutpat ac tincidunt vitae semper. Purus non enim praesent elementum facilisis leo. Orci phasellus egestas tellus rutrum tellus pellentesque. Pharetra sit amet aliquam id diam. Lorem dolor sed viverra ipsum nunc aliquet bibendum enim. Nulla facilisi morbi tempus iaculis urna id volutpat lacus laoreet. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sed adipiscing diam donec adipiscing tristique risus nec. Maecenas pharetra convallis posuere morbi leo urna molestie. Netus et malesuada fames ac. Velit sed ullamcorper morbi tincidunt ornare. </p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>Habitant morbi tristique</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Diam donec adipiscing tristique risus nec feugiat in fermentum posuere. </p>
<!-- /wp:paragraph -->

<!-- wp:ht-blocks/list {"blockID":"71754823-5b84-4e09-9190-efbb9fee0a87","list":"\u003cli\u003eClick the ⚙ \u003cstrong\u003egear icon\u003c/strong\u003e to go to your \u003ca href=\u0022#\u0022\u003eAccount Settings\u003c/a\u003e.\u003c/li\u003e\u003cli\u003eOn the \u003cstrong\u003eBilling\u003c/strong\u003e tab, click \u003cstrong\u003eView invoices\u003c/strong\u003e.\u003c/li\u003e","iconRound":"99%"} -->
<div class="wp-block-ht-blocks-list heroic-styled-list" id="heroic-styled-list-71754823-5b84-4e09-9190-efbb9fee0a87"><ol class="fa-ul"><li>Click the ⚙ <strong>gear icon</strong> to go to your <a href="#">Account Settings</a>.</li><li>On the <strong>Billing</strong> tab, click <strong>View invoices</strong>.</li></ol><style>#heroic-styled-list-71754823-5b84-4e09-9190-efbb9fee0a87 li:before{
		                   background:#000000;
		                   border-radius: 99%;
		                   }</style></div>
<!-- /wp:ht-blocks/list -->

<!-- wp:paragraph -->
<p>Feugiat nisl pretium fusce id velit ut. Integer eget aliquet nibh praesent tristique magna sit amet. Mollis nunc sed id semper risus in hendrerit gravida rutrum. </p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul><li><strong>Diam sit amet nisl.</strong> Suscipit adipiscing bibendum. Elementum pulvinar etiam non quam lacus. </li><li><strong>Amet mattis vulputate.</strong> Enim nulla aliquet porttitor lacus luctus accumsan. Lorem sed risus ultricies tristique nulla aliquet.</li></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Vel pharetra vel turpis nunc eget lorem dolor sed viverra. Ridiculus mus mauris vitae ultricies. Nulla facilisi etiam dignissim diam quis enim lobortis scelerisque fermentum. Faucibus scelerisque eleifend donec pretium. Cursus sit amet dictum sit amet justo donec enim diam. </p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3>Gravida Neque</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Posuere lorem ipsum dolor sit amet consectetur. Eros donec ac odio tempor orci. </p>
<!-- /wp:paragraph -->

<!-- wp:ht-blocks/messages -->
<p class="wp-block-ht-blocks-messages wp-block-hb-message wp-block-hb-message--withicon"><strong>Tip!</strong><br>This is where you can say something important!</p>
<!-- /wp:ht-blocks/messages -->

<!-- wp:paragraph -->
<p>Turpis nunc eget lorem dolor sed viverra ipsum nunc. In nibh mauris cursus mattis molestie a iaculis at. Morbi tristique senectus et netus et malesuada fames. Eget duis at tellus at urna condimentum mattis pellentesque id. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Tempor commodo ullamcorper a lacus vestibulum sed. Integer eget aliquet nibh praesent tristique. At quis risus sed vulputate odio. Imperdiet sed euismod nisi porta lorem mollis aliquam. Vitae purus faucibus ornare suspendisse sed nisi. Scelerisque in dictum non consectetur a erat nam at lectus. </p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3>Amet Mattis Vulputate</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Est placerat in egestas erat imperdiet sed euismod. Lacus laoreet non curabitur gravida. Placerat vestibulum lectus mauris ultrices eros. Vitae tempus quam pellentesque nec nam aliquam sem et. Consectetur adipiscing elit duis tristique sollicitudin nibh sit amet commodo. </p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":83,"sizeSlug":"medium","linkDestination":"none"} -->
<figure class="wp-block-image size-medium"><img src="<?php do_action('ht_kb_sample_media_url', 'heroic-blocks-message-styles'); ?>" alt="" class="wp-image-83"/><figcaption><em>Heroic Message Block Styles</em></figcaption></figure>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>Risus quis varius quam quisque id diam vel quam elementum:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul><li>Success</li><li>Alert</li><li>Danger</li><li>Information</li></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Tellus mauris a diam maecenas sed enim ut sem viverra. Mus mauris vitae ultricies leo integer. Ornare arcu odio ut sem nulla pharetra diam sit. Pulvinar mattis nunc sed blandit. Risus sed vulputate odio ut enim blandit volutpat maecenas volutpat. </p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3>Suspendisse Interdum</h3>
<!-- /wp:heading -->

<!-- wp:ht-blocks/messages {"className":"is-style-info"} -->
<p class="wp-block-ht-blocks-messages wp-block-hb-message wp-block-hb-message--withicon is-style-info"><strong>Shortcuts</strong><br>Zoom in: CMD+ (Mac) or CTRL + (Windows)<br>Zoom out: CMD – (Mac) or CTRL – (Windows)</p>
<!-- /wp:ht-blocks/messages -->

<!-- wp:paragraph -->
<p>Integer feugiat scelerisque varius morbi enim nunc. Ut aliquam purus sit amet luctus venenatis lectus magna fringilla. Aliquet eget sit amet tellus cras adipiscing enim eu turpis. Purus semper eget duis at tellus at urna. Congue eu consequat ac felis donec. </p>
<!-- /wp:paragraph -->

<!-- wp:code -->
<pre class="wp-block-code"><code>html {background: #fafafa; }</code></pre>
<!-- /wp:code -->

<!-- wp:paragraph -->
<p>Convallis posuere morbi leo urna molestie at. Ullamcorper a lacus vestibulum sed. Dictum at tempor commodo ullamcorper a lacus vestibulum sed. Viverra nibh cras pulvinar mattis. Quis commodo odio aenean sed adipiscing diam donec adipiscing. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Ipsum nunc aliquet bibendum enim. Ultrices neque ornare aenean euismod elementum nisi quis eleifend quam. Malesuada nunc vel risus commodo viverra maecenas. Ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Tortor id aliquet lectus proin nibh. Id nibh tortor id aliquet lectus proin. Odio eu feugiat pretium nibh ipsum consequat nisl vel pretium. </p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>Malesuada Nunc</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>At erat pellentesque adipiscing commodo elit at imperdiet. Ac placerat vestibulum lectus mauris ultrices eros in cursus. Suspendisse interdum consectetur libero id faucibus nisl. Urna nunc id cursus metus aliquam eleifend. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Donec ultrices tincidunt arcu non sodales neque. Viverra orci sagittis eu volutpat odio. </p>
<!-- /wp:paragraph -->

<!-- wp:table -->
<figure class="wp-block-table"><table><thead><tr><th><strong>Language Name</strong></th><th>Language Code</th><th>WordPress Locale Code</th></tr></thead><tbody><tr><td>English</td><td>en</td><td>en_US</td></tr><tr><td>French</td><td>fr</td><td>fr_FR</td></tr><tr><td>German</td><td>de</td><td>de_DE</td></tr><tr><td>Spanish</td><td>es</td><td>es_ES</td></tr><tr><td>Italian</td><td>it</td><td>it_IT</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph -->
<p>Dolor magna eget est lorem ipsum dolor sit amet consectetur. Et ligula ullamcorper malesuada proin libero nunc consequat interdum varius. Scelerisque mauris pellentesque pulvinar pellentesque habitant morbi tristique senectus. Lectus quam id leo in.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Tempus egestas sed sed risus pretium quam vulputate dignissim suspendisse. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Turpis egestas pretium aenean pharetra magna ac placerat vestibulum lectus. Ut sem viverra aliquet eget sit amet tellus cras. Eu consequat ac felis donec et odio. Dictum varius duis at consectetur. Odio morbi quis commodo odio aenean sed adipiscing. In tellus integer feugiat scelerisque varius morbi. Volutpat lacus laoreet non curabitur gravida arcu ac tortor. </p>
<!-- /wp:paragraph -->