<svg width="0" height="0" display="none" xmlns="http://www.w3.org/2000/svg">
  <defs>

    <symbol id="icon-feedbackup" viewBox="0 0 24 24">
      <g stroke-width="2" transform="translate(0, 0)">
        <polyline data-cap="butt" data-color="color-2" points="6 23 1 23 1 12 6 12" fill="none" stroke="#89c053" stroke-miterlimit="10" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></polyline>
        <path d="M6,12,9,1H9a3,3,0,0,1,3,3v6h7.5a3,3,0,0,1,2.965,3.456l-1.077,7A3,3,0,0,1,18.426,23H6Z" fill="none" stroke="#89c053" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" stroke-linejoin="round"></path>
      </g>
    </symbol>

    <symbol id="icon-feedbackdown" viewBox="0 0 24 24">
      <g stroke-width="2" transform="translate(0, 0)">
        <polyline data-cap="butt" data-color="color-2" points="6 1 1 1 1 12 6 12" fill="none" stroke="#e8553e" stroke-miterlimit="10" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></polyline>
        <path d="M6,12,9,23H9a3,3,0,0,0,3-3V14h7.5a3,3,0,0,0,2.965-3.456l-1.077-7A3,3,0,0,0,18.426,1H6Z" fill="none" stroke="#e8553e" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" stroke-linejoin="round"></path>
      </g>
    </symbol>

    <symbol id="icon-edit" viewBox="0 0 24 24">
      <g>
        <circle fill="#000000" cx="12" cy="12" r="2"></circle>
        <circle fill="#000000" cx="3" cy="12" r="2"></circle>
        <circle fill="#000000" cx="21" cy="12" r="2"></circle>
      </g>
    </symbol>
    
    <symbol id="icon-link" viewBox="0 0 24 24">
      <g stroke-width="2" transform="translate(0, 0)"><rect x="2" y="2" width="20" height="20" fill="none" stroke="#0073aa" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2" stroke-linejoin="miter"></rect><line data-cap="butt" data-color="color-2" x1="18" y1="6" x2="10" y2="14" fill="none" stroke="#0073aa" stroke-miterlimit="10" stroke-width="2" stroke-linecap="butt" stroke-linejoin="miter"></line><polyline data-color="color-2" points="18 13 18 6 11 6" fill="none" stroke="#0073aa" stroke-linecap="square" stroke-miterlimit="10" stroke-width="2" stroke-linejoin="miter"></polyline></g>
    </symbol>

  </defs>
</svg>