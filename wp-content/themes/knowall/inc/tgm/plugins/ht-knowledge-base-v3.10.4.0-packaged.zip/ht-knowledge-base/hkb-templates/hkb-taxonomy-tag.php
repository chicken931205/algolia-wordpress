<?php
/**
 * Template for kb tag display
 *
 * @package hkb-templates/
 */

?>

<?php
hkb_get_template_part( 'hkb-taxonomy', 'category' );
